<template>
    <div class="text-center col-12 dailyCard">
        <div>No Data</div>
    </div>
</template>