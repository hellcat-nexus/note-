import type { StreamParser } from '@codemirror/language';
export declare const graphql: StreamParser<any>;
//# sourceMappingURL=mode.d.ts.map