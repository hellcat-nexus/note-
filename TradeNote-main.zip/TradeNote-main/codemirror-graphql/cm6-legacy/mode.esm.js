import graphqlModeFactory from '../utils/mode-factory';
export const graphql = graphqlModeFactory({});
//# sourceMappingURL=mode.js.map