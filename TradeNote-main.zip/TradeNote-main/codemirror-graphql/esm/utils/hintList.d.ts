import type CodeMirror from 'codemirror';
import { IHint, IHints } from '../hint';
export default function hintList(cursor: CodeMirror.Position, token: CodeMirror.Token, list: IHint[]): IHints | undefined;
//# sourceMappingURL=hintList.d.ts.map