export {};
//# sourceMappingURL=info-addon.d.ts.map