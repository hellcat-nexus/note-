import { CharacterStream, ParserOptions, State } from 'graphql-language-service';
export default function runParser(sourceText: string, parserOptions: ParserOptions, callbackFn: (stream: CharacterStream, state: State, style: string) => void): void;
//# sourceMappingURL=runParser.d.ts.map