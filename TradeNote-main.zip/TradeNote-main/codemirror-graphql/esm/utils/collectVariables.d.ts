import { DocumentNode, GraphQLSchema } from 'graphql';
export default function collectVariables(schema: GraphQLSchema, documentAST: DocumentNode): any;
//# sourceMappingURL=collectVariables.d.ts.map