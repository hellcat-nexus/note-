export {};
//# sourceMappingURL=jump-addon.d.ts.map