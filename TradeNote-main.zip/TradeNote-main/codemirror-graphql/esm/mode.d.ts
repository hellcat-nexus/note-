export {};
//# sourceMappingURL=mode.d.ts.map